package com.example;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Maven!");
	// change1:添加一行注释
	// change2:添加第二行注释
	// change3:修改
	// change4:修改
	// change5:修改
	// change6:修改
	// change7:修改
	// change8:Untached Head状态修改
    }
}

